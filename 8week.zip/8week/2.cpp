#include "cv.hpp"
#include <iostream>

using namespace std;
using namespace cv;

int main() {
    Mat image, binary, adaptive_binary; 
    image = imread("adaptive_1.jpg", 0);

    threshold(image, binary, 150, 255, THRESH_BINARY);
    adaptiveThreshold(image, adaptive_binary, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY, 85, 15);
    
    imshow("Input image", image); 
    imshow("Binary", binary);
    imshow("Result", adaptive_binary); 
    
    waitKey(0);
    return 0;
}